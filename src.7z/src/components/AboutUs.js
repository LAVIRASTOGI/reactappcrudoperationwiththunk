import React, { Component } from 'react';

class AboutUs extends Component {

    constructor(props, context) {
        super(props, context);
    }

    render() {
        return (
            <div>
                About Us !!!
            </div>
        );
    }
}


export default AboutUs;
