import React, { Component } from 'react';

class ContactUs extends Component {

    constructor(props, context) {
        super(props, context);
    }
    
    render() {
        return (
            <div>
                Contact Us !!!
            </div>
        );
    }
}


export default ContactUs;
